import "./App.css";
import { useState } from "react";
import TodoList from "./TodoView";
import Login from "./Login";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  let [user, setUser] = useState(null);
  const greetingForRandom = <p>Tere! Palun logi sisse!</p>;
  const userGreeting = <p>Tere {user?.username}!</p>;

  return (
    <div className="App">
      <header className="App-header">
        {!user && greetingForRandom}
        {user && userGreeting}

        {!user && <Login user={user} setUser={setUser} />}
        {user && <TodoList user={user} setUser={setUser} />}

      </header>
        <ToastContainer />
    </div>
  );
}

export default App;
